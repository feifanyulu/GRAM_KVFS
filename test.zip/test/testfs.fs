#!/bin/bash

directories=("/mnt/lthfs" "/mnt/ext4" "/mnt/xfs" "/mnt/btrfs")
files=("/home/zxw/test/lthfs_test.csv" "/home/zxw/test/ext4_test.csv" "/home/zxw/test/xfs_test.csv" "/home/zxw/test/btrfs_test.csv")
rw=("read" "write" "randread" "randwrite" "randrw")

sizes=("4K" "64K" "1M" "4M" "64M" "1G")


# seqread
for i in "${!directories[@]}"; do
   dir="${directories[$i]}"
   file="${files[$i]}"
   for op in "${rw[@]}"; do
       for size in "${sizes[@]}"; do
           sudo fio --name=$dir$op$size --ioengine=sync --rw=$op --bs=$size --size=1G --numjobs=1  --direct=1  --directory=$dir --output-format=csv | tee -a $file
       done
   done
done


